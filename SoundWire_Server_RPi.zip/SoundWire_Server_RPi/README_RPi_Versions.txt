Please choose which version of SoundWire Server for Raspberry Pi you wish
to install:

SoundWire_Server_RPi_GUI64.tar.gz - SoundWire Server version 3.1 with Qt5 GUI.
   Built for 64-bit Raspberry Pi OS Bullseye or later.
   Can run without a GUI window but requires Qt5 libraries to be installed.

SoundWire_Server_RPi_GUI32.tar.gz - SoundWire Server version 3.1 with Qt5 GUI.
   Built for 32-bit Raspbian Stretch or later, may work on earlier Raspbian
   versions. Can run without a GUI window but requires Qt5 libraries to be installed.

SoundWire_Server_RPi32_cmdline.tar.gz - SoundWire Server version 2.1.2. This
   version uses the command line only, no GUI. It is suitable for minimal
   systems with no desktop manager or older Raspberry Pi models (e.g. 1 & 2).
   Should work on any 32-bit Raspberry Pi OS. 
